//
//  RitmoRCP.swift
//  TESHelper
//
//  Created by JaLu NoVa on 28/11/24.
//

import SwiftUI

struct RitmoRCP: View {
    var body: some View {
        Text("Ritmo RCP")
    }
}

#Preview {
    RitmoRCP()
}
