//
//  CalculoOxigeno.swift
//  TESHelper
//
//  Created by JaLu NoVa on 28/11/24.
//

import SwiftUI

struct CalculoOxigeno: View {
    var body: some View {
        Text("Cálculo Oxígeno")
    }
}

#Preview {
    CalculoOxigeno()
}
