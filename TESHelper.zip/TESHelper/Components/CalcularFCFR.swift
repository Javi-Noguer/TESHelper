//
//  CalcularFCFR.swift
//  TESHelper
//
//  Created by JaLu NoVa on 28/11/24.
//

import SwiftUI

struct CalcularFCFR: View {
    var body: some View {
        Text("Calcular FC/FR")
    }
}

#Preview {
    CalcularFCFR()
}
