//
//  ContentView.swift
//  TESHelper
//
//  Created by JaLu NoVa on 28/11/24.
//

import SwiftUI

struct MainView: View {
    var body: some View {
        MenuView()
    }
}

#Preview {
    MainView()
}
