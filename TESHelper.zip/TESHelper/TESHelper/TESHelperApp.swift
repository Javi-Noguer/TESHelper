//
//  TESHelperApp.swift
//  TESHelper
//
//  Created by JaLu NoVa on 28/11/24.
//

import SwiftUI

@main
struct TESHelperApp: App {
    var body: some Scene {
        WindowGroup {
            MainView()
        }
    }
}
